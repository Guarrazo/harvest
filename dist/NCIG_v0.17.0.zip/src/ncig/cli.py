from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from .export import write_wb_plans
from .catalog import build_catalog, catalog_report
from .generator import generate_layout, validate_layout
from .io import bundle_layouts, load_buildings, write_json
from .preview import write_previews
from .scanner import build_scan_report, find_entry_nodes, load_observations, infer_anchor_from_entry, proximity_groups
from .viewer import build_viewer
from .routing import build_entrance_route, route_to_dict
from .worldplan import build_world_plan
from .bridge import fingerprint_export, write_template_bridge
from .object_spawner import load_json as load_spawner_json, fingerprint_exact_export, write_probe_relocation, build_exact_manifest, write_exact_object_spawner, write_schema_object_spawner
from .asset_harvest import harvest, harvest_templates
from .reference_nodes import schema_summary
from .module_library import build_module_library, library_report
from .decorator import decorate_layout
from .plan_lint import lint_report
from .resource_resolver import bind_resources, resolve_resource
from .preflight import build_preflight, merge_harvests
from .architecture_catalog import build_architecture_catalog, architecture_catalog_report
from .architecture_assembler import build_architecture_assembly, apply_architecture_to_world_plan


def cmd_generate(args: argparse.Namespace) -> int:
    buildings = load_buildings(args.input)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    layouts = []
    all_errors = []
    catalog = None
    if args.catalog:
        catalog_raw = json.loads(Path(args.catalog).read_text(encoding="utf-8"))
        catalog = catalog_raw.get("catalog", catalog_raw)
    routes = []
    for building in buildings:
        try:
            layout = generate_layout(building)
            errors = validate_layout(layout)
            if errors:
                all_errors.append({"building": building.id, "errors": errors})
                continue
            layouts.append(layout)
        except Exception as exc:  # noqa: BLE001
            all_errors.append({"building": building.id, "errors": [str(exc)]})

    write_json(out / "layouts.json", bundle_layouts(layouts))
    write_wb_plans(layouts, out / "wb_plans")
    for layout in layouts:
        write_previews(layout, out / "previews")
        write_json(
            out / "wb_plans" / f"{layout.building.id}_world_plan_v2.json",
            build_world_plan(
                layout,
                catalog,
                playable_shell=args.playable_shell,
                collision_preset=args.collision_preset,
                collision_material=args.collision_material,
            ),
        )
        if args.playable_shell:
            from .shell import build_playable_shell
            write_json(
                out / "shells" / f"{layout.building.id}_playable_shell.json",
                build_playable_shell(layout, collision_preset=args.collision_preset, collision_material=args.collision_material),
            )

    summary = {
        "generator_version": "0.14.0",
        "input_buildings": len(buildings),
        "generated": len(layouts),
        "failed": len(all_errors),
        "failures": all_errors,
        "world_plan_format": "ncig-world-plan-v3",
        "real_asset_catalog": bool(args.catalog),
        "playable_shell": bool(args.playable_shell),
        "collision_shell": bool(args.collision_preset and args.collision_material),
    }
    write_json(out / "summary.json", summary)
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0 if not all_errors else 2


def cmd_scan(args: argparse.Namespace) -> int:
    observations = load_observations(args.input)
    report = build_scan_report(observations)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    write_json(out, report)
    if args.anchors_out:
        entries = find_entry_nodes(observations)
        groups = proximity_groups(entries, args.group_radius)
        anchors = []
        for idx, group in enumerate(groups, start=1):
            if not group:
                continue
            entry = group[0]
            a = infer_anchor_from_entry(
                entry,
                default_width_m=args.width,
                default_depth_m=args.depth,
                default_floors=args.floors,
                district=args.district,
            )
            # Make IDs unique even when the runtime exposes multiple nodes with the same name.
            if any(x["id"] == a.id for x in anchors):
                a = a.__class__(**{**a.__dict__, "id": f"{a.id}_{idx:03d}"})
            record = asdict(a)
            record["tags"] = list(record["tags"])
            anchors.append(record)
        write_json(args.anchors_out, {"buildings": anchors, "format": "ncig-buildings-v1"})
        report["generated_anchors"] = len(anchors)
        write_json(out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def cmd_routes(args: argparse.Namespace) -> int:
    buildings = {b.id: b for b in load_buildings(args.buildings)}
    observations = load_observations(args.scan)
    routes = []
    for entry in find_entry_nodes(observations):
        matches = sorted(
            buildings.values(),
            key=lambda b: (b.position.x-entry.position.x) ** 2 + (b.position.y-entry.position.y) ** 2 + (b.position.z-entry.position.z) ** 2,
        )
        if not matches:
            continue
        building = matches[0]
        layout = generate_layout(building)
        routes.append(route_to_dict(build_entrance_route(building, layout, entry)))
    write_json(args.out, {"format": "ncig-entrance-routes-v1", "routes": routes})
    print(json.dumps({"routes": len(routes), "written": args.out}, indent=2, ensure_ascii=False))
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    data = json.loads(Path(args.layout).read_text(encoding="utf-8"))
    failures = []
    for raw in data.get("layouts", []):
        if not raw.get("building", {}).get("id"):
            failures.append("layout with missing building.id")
        if not raw.get("rooms"):
            failures.append(f"{raw.get('building', {}).get('id', '?')}: no rooms")
        if not raw.get("sectors"):
            failures.append(f"{raw.get('building', {}).get('id', '?')}: no sectors")
        sockets = raw.get("sockets", [])
        if raw.get("building", {}).get("floors", 1) >= 1 and not any(s.get("kind") == "entry" for s in sockets):
            failures.append(f"{raw.get('building', {}).get('id', '?')}: no generated building entry")
    print(json.dumps({"valid": not failures, "failures": failures}, indent=2, ensure_ascii=False))
    return 0 if not failures else 2


def cmd_viewer(args: argparse.Namespace) -> int:
    path = build_viewer(args.preview_dir, args.out)
    print(path)
    return 0


def cmd_catalog(args: argparse.Namespace) -> int:
    catalog = build_catalog(args.root)
    write_json(args.out, {"format": "ncig-resource-catalog-v2", "root": str(Path(args.root).resolve()), "catalog": catalog})
    print(json.dumps({"written": args.out, **catalog_report(catalog)}, indent=2, ensure_ascii=False))
    return 0


def cmd_preview(args: argparse.Namespace) -> int:
    data = json.loads(Path(args.layout).read_text(encoding="utf-8"))
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    from .model import BuildingAnchor, Layout, Room, Sector, Socket, Vec3
    for raw in data.get("layouts", []):
        braw = raw["building"]
        pos = braw["position"]
        b = BuildingAnchor(
            id=braw["id"], district=braw.get("district", ""), type=braw.get("type", "residential"),
            position=Vec3(**pos), yaw_deg=braw.get("yaw_deg", 0), width_m=braw["width_m"], depth_m=braw["depth_m"],
            floors=braw.get("floors", 1), entry_width_m=braw.get("entry_width_m", 1),
            entry_height_m=braw.get("entry_height_m", 2.1), seed=braw.get("seed"), tags=tuple(braw.get("tags", [])),
        )
        rooms = [Room(**x) for x in raw["rooms"]]
        sockets = [Socket(**x) for x in raw.get("sockets", [])]
        sectors = [Sector(
            id=x["id"], building_id=x["building_id"], floor=x["floor"], category=x["category"],
            min_xyz=Vec3(**x["min_xyz"]), max_xyz=Vec3(**x["max_xyz"]), rooms=x["rooms"]
        ) for x in raw.get("sectors", [])]
        layout = Layout(b, rooms, sockets, sectors, raw.get("warnings", []))
        write_previews(layout, out)
    return 0


def _cmd_fingerprint(args: argparse.Namespace) -> int:
    report = fingerprint_export(args.input)
    write_json(args.out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def _cmd_bridge(args: argparse.Namespace) -> int:
    result = write_template_bridge(args.plan, args.template, args.out)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def _cmd_exact_fingerprint(args: argparse.Namespace) -> int:
    data = load_spawner_json(args.input)
    report = fingerprint_exact_export(data)
    write_json(args.out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def _cmd_probe(args: argparse.Namespace) -> int:
    meta = write_probe_relocation(args.template, args.out, args.dx, args.dy, args.dz)
    print(json.dumps({"written": args.out, **meta}, indent=2, ensure_ascii=False))
    return 0


def _cmd_readiness(args: argparse.Namespace) -> int:
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    template = load_spawner_json(args.template)
    report = build_exact_manifest(plan, template)
    write_json(args.out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def _cmd_exact_bridge(args: argparse.Namespace) -> int:
    meta = write_exact_object_spawner(args.plan, args.template, args.out)
    print(json.dumps({"written": args.out, **meta}, indent=2, ensure_ascii=False))
    return 0



def _cmd_harvest(args: argparse.Namespace) -> int:
    report = harvest(args.root)
    if args.templates_out:
        write_json(args.templates_out, harvest_templates(args.root))
    write_json(args.out, report)
    print(json.dumps({"written": args.out, "resource_count": report["resource_count"], "node_type_mentions": report["node_type_mentions"]}, indent=2, ensure_ascii=False))
    return 0


def _cmd_schema(args: argparse.Namespace) -> int:
    report = schema_summary()
    write_json(args.out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def _cmd_schema_bridge(args: argparse.Namespace) -> int:
    meta = write_schema_object_spawner(args.plan, args.out, base_export_path=args.base, assets_path=args.assets, templates_path=args.templates, decoration_path=args.decoration, report_path=args.report)
    print(json.dumps({"written": args.out, **meta}, indent=2, ensure_ascii=False))
    return 0



def _cmd_bind_resources(args: argparse.Namespace) -> int:
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    assets = json.loads(Path(args.assets).read_text(encoding="utf-8"))
    bound_plan, report = bind_resources(plan, assets, overwrite=args.overwrite)
    write_json(args.out, bound_plan)
    if args.report:
        write_json(args.report, report)
    print(json.dumps({"written": args.out, "bound": report["bound_count"], "unresolved": report["unresolved_count"], "skipped": report["skipped_count"]}, indent=2, ensure_ascii=False))
    return 0 if report["unresolved_count"] == 0 else 2


def _cmd_resource_check(args: argparse.Namespace) -> int:
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    assets = json.loads(Path(args.assets).read_text(encoding="utf-8"))
    nodes = []
    for node in plan.get("nodes", []) or []:
        if not isinstance(node, dict) or node.get("type") not in {"worldMeshNode", "worldEntityNode"}:
            continue
        result = resolve_resource(node, assets)
        nodes.append({"name": node.get("name"), "type": node.get("type"), **result})
    report = {
        "format": "ncig-resource-check-v1",
        "node_count": len(nodes),
        "resolved": sum(bool(x.get("resource")) for x in nodes),
        "unresolved": sum(not bool(x.get("resource")) for x in nodes),
        "nodes": nodes,
    }
    write_json(args.out, report)
    print(json.dumps({"written": args.out, "node_count": report["node_count"], "resolved": report["resolved"], "unresolved": report["unresolved"]}, indent=2, ensure_ascii=False))
    return 0 if report["unresolved"] == 0 else 2



def _cmd_preflight(args: argparse.Namespace) -> int:
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    assets = json.loads(Path(args.assets).read_text(encoding="utf-8")) if args.assets else None
    templates = json.loads(Path(args.templates).read_text(encoding="utf-8")) if args.templates else None
    base = load_spawner_json(args.base) if args.base else None
    report = build_preflight(plan, assets=assets, templates=templates, base_export=base)
    write_json(args.out, report)
    print(json.dumps({"written": args.out, "ready": report["ready"], **report["summary"]}, indent=2, ensure_ascii=False))
    return 0 if report["ready"] else 2



def _cmd_sync_harvest(args: argparse.Namespace) -> int:
    manifest = sync_github_harvest(args.source, args.out, ref=args.ref, include_optional=not args.required_only)
    print(json.dumps({"written": str(Path(args.out).resolve()), **manifest}, indent=2, ensure_ascii=False))
    return 0


def _cmd_architecture_catalog(args: argparse.Namespace) -> int:
    harvest_data = json.loads(Path(args.harvest).read_text(encoding="utf-8"))
    catalog = build_architecture_catalog(
        harvest_data,
        max_per_class=args.max_per_class,
        max_total=args.max_total,
        interior_only=args.interior_only,
    )
    write_json(args.out, catalog)
    print(json.dumps({"written": args.out, **architecture_catalog_report(catalog)}, indent=2, ensure_ascii=False))
    return 0



def _cmd_architecture_assemble(args: argparse.Namespace) -> int:
    from .model import BuildingAnchor, Layout, Room, Sector, Socket, Vec3
    raw = json.loads(Path(args.layouts).read_text(encoding="utf-8"))
    catalog_raw = json.loads(Path(args.catalog).read_text(encoding="utf-8"))
    catalog = catalog_raw.get("catalog", catalog_raw)
    layouts = []
    for raw_layout in raw.get("layouts", []):
        braw = raw_layout["building"]
        b = BuildingAnchor(
            id=braw["id"], district=braw.get("district", ""), type=braw.get("type", "residential"),
            position=Vec3(**braw["position"]), yaw_deg=braw.get("yaw_deg", 0),
            width_m=braw["width_m"], depth_m=braw["depth_m"], floors=braw.get("floors", 1),
            entry_width_m=braw.get("entry_width_m", 1), entry_height_m=braw.get("entry_height_m", 2.1),
            seed=braw.get("seed"), tags=tuple(braw.get("tags", [])),
        )
        rooms=[Room(**x) for x in raw_layout["rooms"]]
        sockets=[Socket(**x) for x in raw_layout.get("sockets", [])]
        sectors=[Sector(id=x["id"], building_id=x["building_id"], floor=x["floor"], category=x["category"],
                        min_xyz=Vec3(**x["min_xyz"]), max_xyz=Vec3(**x["max_xyz"]), rooms=x["rooms"])
                 for x in raw_layout.get("sectors", [])]
        layouts.append(Layout(b, rooms, sockets, sectors, raw_layout.get("warnings", [])))
    result = build_architecture_assembly(layouts, catalog)
    write_json(args.out, result)
    print(json.dumps({"written": args.out, "buildings": len(result.get("buildings", [])),
                      "placements": sum(int(b.get("placement_count", 0)) for b in result.get("buildings", []))}, indent=2, ensure_ascii=False))
    return 0


def _cmd_architecture_apply(args: argparse.Namespace) -> int:
    plan=json.loads(Path(args.plan).read_text(encoding="utf-8"))
    assembly=json.loads(Path(args.assembly).read_text(encoding="utf-8"))
    result=apply_architecture_to_world_plan(plan, assembly)
    write_json(args.out, result)
    print(json.dumps({"written": args.out, "nodes": len(result.get("nodes", [])),
                      "added_architecture_nodes": result.get("architecture", {}).get("added_node_count", 0),
                      "skipped_unresolved": result.get("architecture", {}).get("skipped_unresolved_count", 0)}, indent=2, ensure_ascii=False))
    return 0

def _cmd_architecture_audit(args: argparse.Namespace) -> int:
    catalog_raw = json.loads(Path(args.catalog).read_text(encoding="utf-8"))
    catalog = catalog_raw.get("catalog", catalog_raw)
    assembly = json.loads(Path(args.assembly).read_text(encoding="utf-8"))
    items = catalog.get("items", []) if isinstance(catalog, dict) else []
    complete = sum(bool((x.get("dimensions") or {}).get("complete")) for x in items if isinstance(x, dict))
    by_class = {}
    for cls in ["floor_piece", "wall_piece", "ceiling_piece", "door_frame", "door_piece", "window_piece", "pillar_piece", "stairs_piece"]:
        by_class[cls] = sum(1 for x in items if isinstance(x, dict) and x.get("class") == cls)
    unresolved = sum(int(b.get("unresolved_count", 0)) for b in assembly.get("buildings", []))
    placements = sum(int(b.get("placement_count", 0)) for b in assembly.get("buildings", []))
    report = {
        "format": "ncig-architecture-audit-v1",
        "catalog_selected_count": catalog.get("selected_count"),
        "catalog_complete_dimension_hints": complete,
        "catalog_class_counts": by_class,
        "assembly_buildings": len(assembly.get("buildings", [])),
        "assembly_placements": placements,
        "assembly_unresolved": unresolved,
        "bounds_validation_required": True,
        "native_worldMesh_template_required": True,
        "ready_for_native_mesh_export": False,
        "reason": "A real worldMeshNode template from the installed World Builder/entSpawner export is still required before native Object Spawner export.",
    }
    write_json(args.out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def _cmd_probe_plan(args: argparse.Namespace) -> int:
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    templates = json.loads(Path(args.templates).read_text(encoding="utf-8"))
    available = sorted({str(n.get("type")) for s in (templates.get("templates") or {}).values() if isinstance(s, list) for n in s if isinstance(n, dict)})
    wanted = sorted({str(n.get("type")) for n in plan.get("nodes", []) if isinstance(n, dict)})
    missing = [x for x in wanted if x not in available]
    probe_rows = []
    labels = {
        "worldMeshNode": "Create/export one simple mesh node (e.g. cube/plane) from World Builder/entSpawner.",
        "worldCollisionNode": "Create/export one small collision box with known preset/material.",
        "worldStaticMarkerNode": "Create/export one empty/static marker.",
        "worldStaticLightNode": "Create/export one static light with default profile.",
        "worldInteriorAreaNode": "Create/export one small interior area if the exporter exposes it.",
        "worldAmbientAreaNode": "Create/export one ambient area if the exporter exposes it.",
    }
    for typ in missing:
        probe_rows.append({"node_type": typ, "action": labels.get(typ, "Export one real node of this type from the installed toolchain."), "required": True})
    report = {
        "format": "ncig-native-probe-plan-v1",
        "available_node_types": available,
        "required_node_types": wanted,
        "missing_node_types": missing,
        "probes": probe_rows,
        "note": "The probe plan does not fabricate runtime payload fields; it identifies the smallest real exports needed to learn them.",
    }
    write_json(args.out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0

def _cmd_merge_harvest(args: argparse.Namespace) -> int:
    harvests = [json.loads(Path(path).read_text(encoding="utf-8")) for path in args.inputs]
    merged = merge_harvests(*harvests)
    write_json(args.out, merged)
    print(json.dumps({"written": args.out, "resource_count": merged["resource_count"], "node_type_mentions": merged["node_type_mentions"]}, indent=2, ensure_ascii=False))
    return 0

def _cmd_plan_lint(args: argparse.Namespace) -> int:
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    report = lint_report(plan)
    write_json(args.out, report)
    print(json.dumps({"written": args.out, **{k: report[k] for k in ("valid", "errors", "warnings")}}, indent=2, ensure_ascii=False))
    return 0 if report["valid"] else 2

def _cmd_modules(args: argparse.Namespace) -> int:
    harvest_path = Path(args.harvest)
    data = json.loads(harvest_path.read_text(encoding="utf-8"))
    library = build_module_library(data)
    write_json(args.out, library)
    print(json.dumps({"written": args.out, **library_report(library)}, indent=2, ensure_ascii=False))
    return 0


def _cmd_decorate(args: argparse.Namespace) -> int:
    data = json.loads(Path(args.layout).read_text(encoding="utf-8"))
    library = json.loads(Path(args.library).read_text(encoding="utf-8"))
    from .model import BuildingAnchor, Layout, Room, Sector, Socket, Vec3
    outputs = []
    for raw in data.get("layouts", []):
        braw = raw["building"]
        bpos = braw["position"]
        b = BuildingAnchor(
            id=braw["id"], district=braw.get("district", ""), type=braw.get("type", "residential"),
            position=Vec3(**bpos), yaw_deg=braw.get("yaw_deg", 0), width_m=braw["width_m"], depth_m=braw["depth_m"],
            floors=braw.get("floors", 1), entry_width_m=braw.get("entry_width_m", 1),
            entry_height_m=braw.get("entry_height_m", 2.1), seed=braw.get("seed"), tags=tuple(braw.get("tags", [])),
        )
        layout = Layout(
            b, [Room(**x) for x in raw.get("rooms", [])], [Socket(**x) for x in raw.get("sockets", [])],
            [Sector(id=x["id"], building_id=x["building_id"], floor=x["floor"], category=x["category"], min_xyz=Vec3(**x["min_xyz"]), max_xyz=Vec3(**x["max_xyz"]), rooms=x.get("rooms", [])) for x in raw.get("sectors", [])],
            raw.get("warnings", []),
        )
        outputs.append(decorate_layout(layout, library, density=args.density))
    write_json(args.out, {"format": "ncig-decoration-bundle-v1", "layouts": outputs})
    print(json.dumps({"written": args.out, "buildings": len(outputs), "total_placements": sum(x["placement_count"] for x in outputs), "total_nodes": sum(x["node_count"] for x in outputs)}, indent=2, ensure_ascii=False))
    return 0

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="ncig", description="Night City Interior Generator")
    sub = p.add_subparsers(dest="command", required=True)

    g = sub.add_parser("generate")
    g.add_argument("--input", required=True)
    g.add_argument("--out", required=True)
    g.add_argument("--catalog", help="NCIG resource catalog JSON")
    g.add_argument("--playable-shell", action="store_true", help="Add room areas and optional collision shell specs")
    g.add_argument("--collision-preset", help="Exact verified World Builder collision preset; enables collision nodes with --collision-material")
    g.add_argument("--collision-material", help="Exact verified collision material; used with --collision-preset")
    g.set_defaults(func=cmd_generate)

    s = sub.add_parser("scan", help="Turn runtime node observations into entry candidates/anchors")
    s.add_argument("--input", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--anchors-out")
    s.add_argument("--district", default="unknown")
    s.add_argument("--width", type=float, default=10.0)
    s.add_argument("--depth", type=float, default=10.0)
    s.add_argument("--floors", type=int, default=1)
    s.add_argument("--group-radius", type=float, default=12.0)
    s.set_defaults(func=cmd_scan)

    r = sub.add_parser("routes", help="Match scanned doors to generated building anchors")
    r.add_argument("--buildings", required=True)
    r.add_argument("--scan", required=True)
    r.add_argument("--out", required=True)
    r.set_defaults(func=cmd_routes)

    v = sub.add_parser("validate")
    v.add_argument("--layout", required=True)
    v.set_defaults(func=cmd_validate)

    pv = sub.add_parser("preview")
    pv.add_argument("--layout", required=True)
    pv.add_argument("--out", required=True)
    pv.set_defaults(func=cmd_preview)

    c = sub.add_parser("catalog")
    c.add_argument("--root", required=True, help="Root of a directory extracted/uncooked with WolvenKit")
    c.add_argument("--out", required=True)
    c.set_defaults(func=cmd_catalog)

    xfp = sub.add_parser("exact-fingerprint", help="Fingerprint the exact World Builder Object Spawner envelope")
    xfp.add_argument("--input", required=True)
    xfp.add_argument("--out", required=True)
    xfp.set_defaults(func=_cmd_exact_fingerprint)

    pr = sub.add_parser("probe-relocate", help="Relocate the real worldEntityNode from a supplied World Builder export")
    pr.add_argument("--template", required=True)
    pr.add_argument("--out", required=True)
    pr.add_argument("--dx", type=float, default=0.0)
    pr.add_argument("--dy", type=float, default=0.0)
    pr.add_argument("--dz", type=float, default=3.2)
    pr.set_defaults(func=_cmd_probe)

    ex = sub.add_parser("exact-bridge", help="Build an exact World Builder/Object Spawner JSON from real node templates")
    ex.add_argument("--plan", required=True)
    ex.add_argument("--template", required=True)
    ex.add_argument("--out", required=True)
    ex.set_defaults(func=_cmd_exact_bridge)

    rd = sub.add_parser("readiness", help="Report which NCIG node classes have real templates in a World Builder export")
    rd.add_argument("--plan", required=True)
    rd.add_argument("--template", required=True)
    rd.add_argument("--out", required=True)
    rd.set_defaults(func=_cmd_readiness)

    fp = sub.add_parser("fingerprint", help="Inspect an actual World Builder/Object Spawner export JSON")
    fp.add_argument("--input", required=True)
    fp.add_argument("--out", required=True)
    fp.set_defaults(func=lambda a: _cmd_fingerprint(a))

    br = sub.add_parser("bridge", help="Apply an NCIG world plan to a real Object Spawner export template")
    br.add_argument("--plan", required=True)
    br.add_argument("--template", required=True)
    br.add_argument("--out", required=True)
    br.set_defaults(func=lambda a: _cmd_bridge(a))

    hv = sub.add_parser("harvest", help="Harvest resources and real WB/Object Spawner templates from a World Builder/mod data directory")
    hv.add_argument("--root", required=True, help="Root such as ...\\entSpawner or a mod data folder")
    hv.add_argument("--out", required=True)
    hv.add_argument("--templates-out", help="Also write collected real node templates")
    hv.set_defaults(func=_cmd_harvest)

    sc = sub.add_parser("schema-report", help="Write the public/reference node schema registry used by NCIG")
    sc.add_argument("--out", required=True)
    sc.set_defaults(func=_cmd_schema)

    sb = sub.add_parser("schema-bridge", help="Build Object Spawner JSON from NCIG using public exporter schemas and harvested templates/assets")
    sb.add_argument("--plan", required=True)
    sb.add_argument("--out", required=True)
    sb.add_argument("--base", help="Optional real WB export JSON used only for sector/envelope fields")
    sb.add_argument("--assets", help="ncig-harvest-v1 JSON")
    sb.add_argument("--templates", help="ncig-template-harvest-v1 JSON")
    sb.add_argument("--decoration", help="ncig-decoration-bundle-v1 JSON to compose harvested modules into the native export")
    sb.add_argument("--report", help="Optional sidecar NCIG diagnostics JSON; omitted from the native export itself")
    sb.set_defaults(func=_cmd_schema_bridge)

    rb = sub.add_parser("bind-resources", help="Bind unassigned mesh/entity nodes to deterministic harvested resources")
    rb.add_argument("--plan", required=True)
    rb.add_argument("--assets", required=True, help="ncig-harvest-v1 or ncig-resource-catalog-v2 JSON")
    rb.add_argument("--out", required=True)
    rb.add_argument("--report")
    rb.add_argument("--overwrite", action="store_true")
    rb.set_defaults(func=_cmd_bind_resources)

    rc = sub.add_parser("resource-check", help="Audit resource resolution against a harvested asset catalog")
    rc.add_argument("--plan", required=True)
    rc.add_argument("--assets", required=True)
    rc.add_argument("--out", required=True)
    rc.set_defaults(func=_cmd_resource_check)

    pf = sub.add_parser("preflight", help="Gate native export on template/resource readiness")
    pf.add_argument("--plan", required=True)
    pf.add_argument("--out", required=True)
    pf.add_argument("--assets", help="ncig-harvest-v1 JSON")
    pf.add_argument("--templates", help="ncig-template-harvest-v1 JSON")
    pf.add_argument("--base", help="Optional real World Builder/Object Spawner export")
    pf.set_defaults(func=_cmd_preflight)

    sh = sub.add_parser("sync-harvest", help="Download a public GitHub harvest into a local NCIG cache")
    sh.add_argument("--source", required=True, help="Public GitHub repository URL, e.g. https://github.com/owner/repo")
    sh.add_argument("--out", required=True, help="Destination directory for the local harvest cache")
    sh.add_argument("--ref", default="main")
    sh.add_argument("--required-only", action="store_true", help="Download only harvest.json and templates.json")
    sh.set_defaults(func=_cmd_sync_harvest)

    ac = sub.add_parser("architecture-catalog", help="Build a compact structural/interior asset catalog from ncig-harvest-v1")
    ac.add_argument("--harvest", required=True, help="ncig-harvest-v1 JSON from the harvest command")
    ac.add_argument("--out", required=True)
    ac.add_argument("--max-per-class", type=int, default=250)
    ac.add_argument("--max-total", type=int)
    ac.add_argument("--interior-only", action="store_true", help="Keep only resources classified as interior architecture")
    ac.set_defaults(func=_cmd_architecture_catalog)

    aa = sub.add_parser("architecture-assemble", help="Assemble real harvested architecture pieces around generated rooms")
    aa.add_argument("--layouts", required=True, help="NCIG layouts.json")
    aa.add_argument("--catalog", required=True, help="ncig-architecture-catalog-v1 JSON")
    aa.add_argument("--out", required=True)
    aa.set_defaults(func=_cmd_architecture_assemble)

    ap = sub.add_parser("architecture-apply", help="Apply an architecture assembly to an NCIG world plan")
    ap.add_argument("--plan", required=True)
    ap.add_argument("--assembly", required=True)
    ap.add_argument("--out", required=True)
    ap.set_defaults(func=_cmd_architecture_apply)

    aud = sub.add_parser("architecture-audit", help="Audit catalog/assembly coverage and native export readiness")
    aud.add_argument("--catalog", required=True)
    aud.add_argument("--assembly", required=True)
    aud.add_argument("--out", required=True)
    aud.set_defaults(func=_cmd_architecture_audit)

    pp = sub.add_parser("probe-plan", help="List missing real World Builder node templates needed by a plan")
    pp.add_argument("--plan", required=True)
    pp.add_argument("--templates", required=True)
    pp.add_argument("--out", required=True)
    pp.set_defaults(func=_cmd_probe_plan)


    mh = sub.add_parser("merge-harvest", help="Merge multiple ncig-harvest-v1 JSON catalogs")
    mh.add_argument("--inputs", nargs="+", required=True)
    mh.add_argument("--out", required=True)
    mh.set_defaults(func=_cmd_merge_harvest)

    pl = sub.add_parser("plan-lint", help="Validate floor assignments, sectors and nodeRef invariants in an NCIG world plan")
    pl.add_argument("--plan", required=True)
    pl.add_argument("--out", required=True)
    pl.set_defaults(func=_cmd_plan_lint)

    ml = sub.add_parser("modules", help="Build a reusable module library from harvested World Builder/mod templates")
    ml.add_argument("--harvest", required=True, help="ncig-template-harvest-v1 JSON from the harvest command")
    ml.add_argument("--out", required=True)
    ml.set_defaults(func=_cmd_modules)

    dc = sub.add_parser("decorate", help="Place harvested modules into generated rooms")
    dc.add_argument("--layout", required=True, help="NCIG layouts.json")
    dc.add_argument("--library", required=True, help="ncig-module-library-v1 JSON")
    dc.add_argument("--out", required=True)
    dc.add_argument("--density", type=float, default=0.65)
    dc.set_defaults(func=_cmd_decorate)

    vw = sub.add_parser("viewer")
    vw.add_argument("--preview-dir", required=True)
    vw.add_argument("--out", required=True)
    vw.set_defaults(func=cmd_viewer)
    return p


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)

if __name__ == "__main__":
    raise SystemExit(main())
